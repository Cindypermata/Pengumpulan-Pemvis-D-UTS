/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.tester;

import java.util.Scanner;

/**
 *
 * @author acer
 */
public class Tester {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Masukkan Nilai Operan 1 :");
        int q = input.nextInt();
        System.out.println("Masukkan Nilai Operan 2 :");
        int r = input.nextInt();
        
        Calculator n = new Calculator();
        
        // Set nilai operan
        n.isiOperan1(q);
        n.isiOperan2(r);

        // Tampilkan hasil operasi
        System.out.println("Penjumlahan: " + n.tambah());
        System.out.println("Pengurangan: " + n.kurang());
        System.out.println("Perkalian: " + n.kali());
        System.out.println("Pembagian: " + n.bagi());
        System.out.println("Pangkat: " + n.pangkat());
    }
}