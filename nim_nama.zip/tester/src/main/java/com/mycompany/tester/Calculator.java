/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tester;

/**
 *
 * @author acer
 */

class Calculator {
    double operan1;
    double operan2;

    public void isiOperan1(double x) {
        this.operan1 = x;
    }

    public void isiOperan2(double x) {
        this.operan2 = x;
    }

    public double tambah() {
        return operan1 + operan2;
    }

    public double kurang() {
        return operan1 - operan2;
    }

    public double kali() {
        return operan1 * operan2;
    }

    public double bagi() {
        return operan1 / operan2;
    }

    public double pangkat() {
        return Math.pow(operan1, operan2);
    }
}